﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace WebNavigation.Models.ViewModels
{
    public class GroupeNbEtd
    {
        public int Id { get; set; }
        [Display(Name = "Groupe")]
        public string LibGroupe { get; set; }
        [Display(Name = "Nombre Etudiants")]
        public int NbrEtd { get; set; }
    }
}
