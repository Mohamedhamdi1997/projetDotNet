﻿using System.ComponentModel.DataAnnotations;

namespace WebNavigation.Models.ViewModels
{
    public class EtdMatiere
    {
        public int Id { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
        [Display(Name = "Matiére")]
        public string LibMatiere { get; set; }
    }
}
