﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebNavigation.Models;
using WebNavigation.Models.ViewModels;

namespace WebNavigation.Data
{
    public class WebNavigationContext : DbContext
    {
        public WebNavigationContext (DbContextOptions<WebNavigationContext> options)
            : base(options)
        {
        }
        public DbSet<Groupe> Groupe { get; set; }
        public DbSet<Etudiant> Etudiant { get; set; }
        public DbSet<Inscription> Inscription { get; set; }
        public DbSet<Matiere> Matiere { get; set; }
        public DbSet<WebNavigation.Models.ViewModels.EtdMatiere>? EtdMatiere { get; set; }
        public DbSet<WebNavigation.Models.ViewModels.GroupeNbEtd>? GroupeNbEtd { get; set; }

      //  public DbSet<WebNavigation.Models.Groupe> Groupe { get; set; } = default!;
    }
}
